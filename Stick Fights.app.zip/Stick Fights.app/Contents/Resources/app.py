import webview

if __name__ == '__main__':
    import os
    path = os.path.abspath(os.path.join(os.path.dirname(__file__), 'index.html'))
    window = webview.create_window('Stick Fights', f'file://{path}', width=850, height=520, resizable=False)
    webview.start()
