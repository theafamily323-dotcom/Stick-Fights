import math
from PIL import Image, ImageDraw

img = Image.new('RGBA', (512, 512), (0, 0, 0, 0))
draw = ImageDraw.Draw(img)

draw.rounded_rectangle([16, 16, 496, 496], radius=110, fill=(24, 24, 24, 255), outline=(255, 0, 68, 255), width=12)

draw.ellipse([216, 90, 296, 170], outline=(255, 0, 68, 255), width=14)
draw.line([256, 170, 256, 320], fill=(255, 0, 68, 255), width=14)
draw.line([256, 210, 340, 180], fill=(255, 0, 68, 255), width=14)
draw.line([256, 210, 180, 240], fill=(255, 0, 68, 255), width=14)
draw.line([256, 320, 180, 420], fill=(255, 0, 68, 255), width=14)
draw.line([256, 320, 330, 420], fill=(255, 0, 68, 255), width=14)

img.save('/tmp/icon.png')
